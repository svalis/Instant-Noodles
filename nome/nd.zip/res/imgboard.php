<?php header('Location: ../imgboard.php?manage'); ?>
